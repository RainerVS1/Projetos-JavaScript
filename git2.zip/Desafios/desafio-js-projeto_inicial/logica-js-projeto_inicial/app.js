// Dia da Semana
diaDaSemana = prompt("Qual dia da semana?")
if (diaDaSemana == `Sábado`) {
    alert("Bom fim de semana!")
}
else if (diaDaSemana == "Domingo") {
    alert("Bom fim de samana!")
}
else {
    alert("Boa semana!")
}

// Verificador de número
numeroVerificar = prompt("Digite o número")
if ( numeroVerificar > 0) {
    alert("Número Positivo!")
}
else {
    alert ("Número Negativo!")
}

// Sistema de pontuação
pontuacao = 90
if (pontuacao >= 100) { 
   console.log("Parabéns, você venceu!")
}
else {
   console.log("Tente novamente para ganhar")
}

// Saldo da conta
let saldoDaconta = 59.12
alert (`Seu saldo é de ${saldoDaconta}.`)

//nome
seuNome = prompt("Qual seu nome?")
alert(`Bem vindo: ${seuNome}`)
